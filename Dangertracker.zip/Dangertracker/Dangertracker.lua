-- Initialize the addon
local addonName, addonTable = ...
local L = addonTable.L

local playerMaxHealth = UnitHealthMax("player")
local damageQueue, healingQueue = {}, {}
local totalDamage = 0
local totalHealing = 0

-- Background setup
local frame = CreateFrame("Frame", "IncomingDataTracker", UIParent, "BackdropTemplate")
frame:SetWidth(100)
frame:SetHeight(200)
frame:SetPoint("CENTER", UIParent, "CENTER")
frame:SetBackdrop({
    bgFile = "Interface/Tooltips/UI-Tooltip-Background",
    edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
    tile = true,
    tileSize = 16,
    edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 }
})
frame:SetBackdropColor(0.1, 0.1, 0.1, 1)
frame:SetResizable(true) 

-- Create damageBar and healingBar first
local damageBar = CreateFrame("StatusBar", nil, frame)
damageBar:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT")
damageBar:SetWidth(50)
damageBar:SetHeight(200)
damageBar:SetOrientation("VERTICAL")
damageBar:SetMinMaxValues(0, 100000)
damageBar:SetStatusBarTexture("Interface\\TARGETINGFRAME\\UI-StatusBar")
damageBar:SetStatusBarColor(1, 0, 0)

-- Create text for damageBar after the bar's size and position have been set
damageBar.text = damageBar:CreateFontString(nil, "OVERLAY")
damageBar.text:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
damageBar.text:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, 10)

-- Healing bar initialised:
local healingBar = CreateFrame("StatusBar", nil, frame)
healingBar:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT")
healingBar:SetWidth(50)
healingBar:SetHeight(200)
healingBar:SetOrientation("VERTICAL")
healingBar:SetMinMaxValues(0, 100000)
healingBar:SetStatusBarTexture("Interface\\TARGETINGFRAME\\UI-StatusBar")
healingBar:SetStatusBarColor(0, 1, 0)
healingBar.text = healingBar:CreateFontString(nil, "OVERLAY")
healingBar.text:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
healingBar.text:SetPoint("BOTTOM", healingBar, "TOP")

-- Function for adjusting sizes of the bars:
local function adjustBarSizes()
    local newWidth = frame:GetWidth()
    local newHeight = frame:GetHeight()
    local barWidth = newWidth / 2 -- Each bar will take half the width of the frame

    if newWidth < 50 then
        frame:SetWidth(50)
        barWidth = 25
    elseif newWidth > 300 then
        frame:SetWidth(300)
    end

    if newHeight < 50 then
        frame:SetHeight(50)
    elseif newHeight > 600 then
        frame:SetHeight(600)
    end

    damageBar:SetWidth(barWidth)
    healingBar:SetWidth(barWidth)
    damageBar:SetHeight(frame:GetHeight())
    healingBar:SetHeight(frame:GetHeight())
end

-- Create an event handler frame
local eventFrame = CreateFrame("Frame")

-- Event handling function
eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" then
        adjustBarSizes()
    end
end)

-- Register for the PLAYER_LOGIN event
eventFrame:RegisterEvent("PLAYER_LOGIN")

-- Make the frame movable
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)

-- Create a resizer frame at the bottom-right corner
local resizer = CreateFrame("Frame", nil, frame)
resizer:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)
resizer:SetSize(16, 16)
resizer:EnableMouse(true)

local resizerTexture = resizer:CreateTexture(nil, "OVERLAY")
resizerTexture:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
resizerTexture:SetAllPoints(resizer)
resizer.texture = resizerTexture

local highlightTexture = resizer:CreateTexture(nil, "HIGHLIGHT")
highlightTexture:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
highlightTexture:SetAllPoints(resizer)

local pushedTexture = resizer:CreateTexture(nil, "ARTWORK")
pushedTexture:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
pushedTexture:SetAllPoints(resizer)

resizer:SetScript("OnMouseDown", function()
    frame:StartSizing()
end)

resizer:SetScript("OnMouseUp", function()
    frame:StopMovingOrSizing()
    adjustBarSizes()
end)

--     local newWidth = frame:GetWidth()
--     local newHeight = frame:GetHeight()
--     local barWidth = newWidth / 2 -- Each bar will take half the width of the frame

--     if newWidth < 50 then -- 100 is a minimum width to ensure that bars don't overlap. Adjust as needed.
--         frame:SetWidth(50)
--         barWidth = 50
--     elseif newWidth > 300 then
--         frame:SetWidth(300)
--     end

--     if newHeight < 50 then
--         frame:SetHeight(50)
--     elseif newHeight > 600 then
--         frame:SetHeight(600)
--     end

--     damageBar:SetWidth(barWidth)
--     healingBar:SetWidth(barWidth)
--     damageBar:SetHeight(frame:GetHeight())
--     healingBar:SetHeight(frame:GetHeight())
-- end)


local function CreateSmoothTransition(bar)
    local animGroup = bar:CreateAnimationGroup()
    local anim = animGroup:CreateAnimation("Animation")
    anim:SetDuration(100000)
    anim:SetScript("OnUpdate", function(self, elapsed)
        local currentValue = bar:GetValue()
        local newValue = currentValue + (self.change * elapsed)
        if (self.change > 0 and newValue > self.targetValue) or (self.change < 0 and newValue < self.targetValue) then
            newValue = self.targetValue
        end
        bar:SetValue(newValue)
    end)
    anim.animGroup = animGroup
    
    animGroup.anim = anim

    return animGroup
end

damageBar.animGroup = CreateSmoothTransition(damageBar)
healingBar.animGroup = CreateSmoothTransition(healingBar)

frame:SetScript("OnEvent", function(self, event, ...)
    if event == "COMBAT_LOG_EVENT_UNFILTERED" then
        local _, eventType, _, _, _, _, _, destGUID, _, _, _, param1, _, _, amount = CombatLogGetCurrentEventInfo()

        if destGUID == UnitGUID("player") then
            if eventType == "SPELL_DAMAGE" or eventType == "RANGE_DAMAGE" or eventType == "SPELL_PERIODIC_DAMAGE" then
                totalDamage = totalDamage + amount
            elseif eventType == "SWING_DAMAGE" then
                totalDamage = totalDamage + param1  -- using param1 here as it's the damage amount for SWING_DAMAGE
            elseif eventType == "SPELL_HEAL" or eventType == "SPELL_PERIODIC_HEAL" then
                totalHealing = totalHealing + amount
            end
        end
    end
end)



local function UpdateBars()
    local function UpdateBarWithAnimation(bar, value)
        local current = bar:GetValue()
        local change = value - current
        bar.animGroup.anim.change = change
        bar.animGroup.anim.targetValue = value
        bar.animGroup:Play()
    end
    
    local dps = totalDamage
    local hps = totalHealing
    
    UpdateBarWithAnimation(damageBar, dps)
    UpdateBarWithAnimation(healingBar, hps)
    

    damageBar.text:SetText(string.format("DIFF: %d", hps - dps))
   -- healingBar.text:SetText(string.format("HPS: %d", hps))
    
    totalDamage, totalHealing = 0, 0
end

C_Timer.NewTicker(1, UpdateBars)

frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
